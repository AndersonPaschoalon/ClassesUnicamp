2.1 Fluxo de Execucao

A classe Booking devera possuir o metodo main(). Como exemplo de execucao, poderao ser feitas as seguintes tarefas:

1. Crie os seguintes Hoteis:
(a) Praia Tropical; Rua Tajuba, 201 - Florianopolis, SC; 3225-8997; R$100 a diaria normal e R$ 900 a diaria vip.
(b) Campo Florestal; Rua Monteiro, 456 - Goiania, GO; 3654-8974; R$50 a diaria normal e R$ 2000 a diaria vip.

2. Crie os seguintes usuarios:
(a) Roberci Silva; 784245698-21; 12/04/1996; Masculino; R$ 1000; fumante.
(b) Marcela Domingues; 269784061-45; 22/07/1998; Feminino; R$ 2000; nao fumante.

3. Crie dois tipos de quartos:
(a) Nao vip; nao aceita fumantes; nao possui ar condicionado.
(b) Vip; aceita fumantes; possui ar condicionado.

4. Crie as seguintes reservas:
(a) Roberci Silva; Hotel Praia Tropical; quarto numero 2; 1 dia.
(b) Marcela Domingues; Hotel Campo Florestal; quarto numero 13; 4 dias.

5. Tente reservar para Roberci Silva, no Hotel Praia Tropical, o quarto de numero 87 por 1 dia.

6. Tente cancelar a reserva de Marcela Domingues no Hotel Praia Tropical, no quarto de numero 22.

7. Reserve para Roberci Silva, no Hotel Campo Florestal, o quarto de numero 99 por 1 dia.

8. Cancele a reserva do item acima.

9. Tente reservar para Marcela Domingues, no Hotel Campo Florestal, o quarto de numero 87 por 1 dia.